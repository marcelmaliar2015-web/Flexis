﻿Flexis DB migrate pack

Contents
- flexis-postgres.dump
- appsettings.Development.local.json (if present)

TokenProtectionKey (must match on new PC):
flexis-dev-google-token-key-32ch!

Restore on new Win11 (flexis-db Postgres running, API stopped):

  $env:PGPASSWORD = "flexis"
  $dump = "...\flexis-postgres.dump"
  & "$env:LOCALAPPDATA\flexis-db\pgsql\bin\pg_restore.exe" -h 127.0.0.1 -U flexis -d flexis --clean --if-exists $dump

Copy appsettings.Development.local.json to:
  backend\src\Flexis.Api\appsettings.Development.local.json

Then start backend\run.bat and frontend\run.bat
